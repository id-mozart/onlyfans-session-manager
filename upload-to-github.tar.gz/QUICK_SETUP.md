# Быстрая настройка (1 клик!)

## ✅ Автоматическая ссылка для создания workflow

Нажмите на эту ссылку - она откроет GitHub с уже заполненным содержимым файла:

**👉 [Создать workflow файл одним кликом](https://github.com/id-mozart/onlyfans-session-manager/new/main?filename=.github/workflows/build-dmg.yml)**

### Что делать:

1. Нажмите на ссылку выше
2. GitHub откроет страницу создания файла с правильным путем
3. **Скопируйте содержимое** из файла `.github/workflows/build-dmg.yml` в этом проекте
4. Вставьте в текстовое поле на GitHub
5. Нажмите **"Commit changes"**

Готово! После этого сборка DMG будет работать.

---

## Альтернатива: Ручное создание

Если ссылка не работает:

1. Откройте: https://github.com/id-mozart/onlyfans-session-manager
2. Нажмите **"Add file" → "Create new file"**
3. В поле "Name your file" введите: `.github/workflows/build-dmg.yml`
4. Скопируйте содержимое из `.github/workflows/build-dmg.yml`
5. Нажмите **"Commit changes"**

---

## После загрузки

Откройте страницу `/build-dmg` и нажмите "Сгенерировать DMG" - всё заработает!
