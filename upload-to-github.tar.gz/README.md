# OnlyFans Session Manager

Desktop application for managing multiple OnlyFans account sessions.

See the Build DMG page in the web interface to trigger .dmg builds.