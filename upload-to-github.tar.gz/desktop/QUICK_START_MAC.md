# 🚀 Быстрая установка для macOS

## Что вы получите?
Файл `OnlyFans Session Manager-1.0.0-mac.dmg` — готовый установщик для Mac, как у любого другого приложения (Chrome, Photoshop, etc.)

---

## ⚡️ 3 простых шага

### 1️⃣ Откройте Terminal
**Где:** Spotlight (⌘ + Space) → введите "Terminal" → Enter

### 2️⃣ Перейдите в папку desktop
```bash
cd путь/к/вашему/проекту/desktop
```

**Пример:**
```bash
cd ~/Documents/onlyfans-session-manager/desktop
```

### 3️⃣ Запустите сборку
```bash
npm install
npm run build:mac
```

**Время:** ~2-5 минут ⏱️

---

## ✅ Готово!

Ваш .dmg файл находится здесь:
```
desktop/dist/OnlyFans Session Manager-1.0.0-mac.dmg
```

---

## 📦 Как установить?

1. **Найдите файл** `.dmg` в папке `desktop/dist/`
2. **Дважды кликните** по файлу
3. **Перетащите** иконку в папку Applications
4. **Запустите** из Launchpad или Applications

---

## 💡 Если нужна универсальная версия

Для работы на **любом Mac** (Intel и Apple Silicon):
```bash
npm run build:mac:universal
```

⚠️ **Дольше:** ~5-10 минут (собирает для двух архитектур)
✅ **Универсальнее:** Работает на всех Mac

---

## ❓ Частые вопросы

### "command not found: npm"
**Решение:** Установите Node.js → https://nodejs.org

### "Cannot build for macOS on Windows/Linux"
**Решение:** .dmg можно создать **только на macOS**

### "Application is damaged"
**Решение:** После установки запустите:
```bash
xattr -cr "/Applications/OnlyFans Session Manager.app"
```

Или: System Settings → Privacy & Security → "Open Anyway"

---

## 📚 Больше информации

- **Подробная инструкция:** [BUILD_MAC.md](./BUILD_MAC.md)
- **Документация:** [README.md](./README.md)

---

**Вопросы?** Откройте [BUILD_MAC.md](./BUILD_MAC.md) для полного руководства! 📖
