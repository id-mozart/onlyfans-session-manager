# OnlyFans Session Manager - Desktop App

Desktop application для управления OnlyFans сессиями с встроенным браузером.

## 🚀 Быстрый старт

### Разработка
```bash
# Установить зависимости
npm install

# Запустить приложение
npm run start
# или
npm run electron:start
```

---

## 📦 Создание установщика

### macOS (.dmg)
```bash
npm run build:mac
```
Результат: `dist/OnlyFans Session Manager-1.0.0-mac.dmg`

📖 **Подробные инструкции:** см. [BUILD_MAC.md](./BUILD_MAC.md)

### Windows (.exe)
```bash
npm run build:win
```
Результат: `dist/OnlyFans Session Manager Setup 1.0.0.exe`

### Linux (.AppImage, .deb)
```bash
npm run build:linux
```
Результат: 
- `dist/OnlyFans Session Manager-1.0.0.AppImage`
- `dist/onlyfans-session-manager_1.0.0_amd64.deb`

---

## 🏗️ Архитектура

```
desktop/
├── main.js              # Главный процесс Electron
├── preload.js           # Preload скрипт (IPC bridge)
├── package.json         # Конфигурация и зависимости
├── icon.png            # Иконка приложения
├── BUILD_MAC.md        # Подробные инструкции для macOS
└── dist/               # Готовые сборки (создается автоматически)
```

### Главные компоненты

**main.js:**
- Создает BrowserWindow для веб-интерфейса
- Создает BrowserView для OnlyFans (embed)
- Управляет cookies через уникальные partitions
- IPC communication с renderer процессом

**preload.js:**
- Безопасный IPC bridge между main и renderer
- Expose только необходимые API
- contextIsolation enabled

---

## 🔧 Конфигурация

### Изменить версию
В `package.json`:
```json
{
  "version": "1.0.1"
}
```

### Изменить название
В `package.json`:
```json
{
  "name": "your-app-name",
  "build": {
    "productName": "Your App Name"
  }
}
```

### Изменить иконку
1. Создайте иконку:
   - macOS: `icon.icns` (1024x1024)
   - Windows: `icon.ico` (256x256)
   - Linux: `icon.png` (512x512)
2. Положите в `desktop/`
3. Обновите `package.json`:
```json
{
  "build": {
    "mac": {
      "icon": "icon.icns"
    },
    "win": {
      "icon": "icon.ico"
    },
    "linux": {
      "icon": "icon.png"
    }
  }
}
```

---

## 🔐 Безопасность

### WebPreferences
```javascript
// Main window (веб-интерфейс)
webPreferences: {
  nodeIntegration: false,
  contextIsolation: true,
  webSecurity: true,
  preload: path.join(__dirname, 'preload.js')
}

// BrowserView (OnlyFans)
webPreferences: {
  nodeIntegration: false,
  contextIsolation: true,
  webSecurity: true,
  partition: `persist:onlyfans-${sessionId}`  // Изоляция
}
```

### Cookie Isolation
Каждая сессия использует уникальную partition:
- `persist:onlyfans-session-1`
- `persist:onlyfans-session-2`
- и т.д.

Это гарантирует, что cookies не смешиваются между аккаунтами.

---

## 🐛 Отладка

### Запуск с DevTools
```bash
NODE_ENV=development npm run start
```

DevTools откроются автоматически для:
- Главного окна (веб-интерфейс)
- BrowserView (OnlyFans) - когда открыт

### Логи
Логи выводятся в консоль терминала:
```bash
npm run start
# Смотрите логи в терминале
```

---

## 📚 Дополнительная информация

- **Полная документация:** [ELECTRON_SETUP.md](../ELECTRON_SETUP.md)
- **macOS Build:** [BUILD_MAC.md](./BUILD_MAC.md)
- **electron-builder docs:** https://www.electron.build

---

## 🎯 Системные требования

### Разработка
- Node.js 18+
- npm 9+
- macOS 10.13+ / Windows 10+ / Linux (Ubuntu 18.04+)

### Production сборка
- **macOS:** Xcode Command Line Tools
- **Windows:** Windows 10+ (для .exe)
- **Linux:** Ubuntu 18.04+ (для .AppImage/.deb)

---

## ⚡️ Команды

| Команда | Описание |
|---------|----------|
| `npm run start` | Запустить приложение (dev) |
| `npm run electron:start` | Запустить с NODE_ENV=development |
| `npm run build:mac` | Создать .dmg для macOS |
| `npm run build:mac:universal` | Создать Universal Binary .dmg |
| `npm run build:win` | Создать .exe для Windows |
| `npm run build:linux` | Создать .AppImage и .deb |
| `npm run build` | Создать для текущей платформы |

---

## 💡 Полезные советы

### Универсальная сборка для macOS
```bash
npm run build:mac:universal
```
- Работает на Intel и Apple Silicon
- Размер файла больше (~2x)
- Рекомендуется для распространения

### Тестирование без сборки
```bash
npm run start
```
- Быстрый запуск для тестирования
- С hot reload (изменения в коде сразу видны)

---

## 📄 Лицензия

MIT
