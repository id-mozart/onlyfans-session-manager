# Создание macOS Installer (.dmg)

## 📦 Быстрый старт

### Требования
- **macOS** (обязательно! Windows/Linux не могут создавать .dmg файлы)
- Node.js 18+ установлен
- Xcode Command Line Tools установлены

### Установка Xcode Command Line Tools
```bash
xcode-select --install
```

---

## 🚀 Создание .dmg файла

### 1. Перейдите в папку desktop
```bash
cd desktop
```

### 2. Установите зависимости (если еще не установлены)
```bash
npm install
```

### 3. Соберите .dmg файл
```bash
npm run build:mac
```

**Результат:** Готовый .dmg файл появится в папке `desktop/dist/`

---

## 📁 Где найти готовый файл?

После успешной сборки:
```
desktop/
  └── dist/
      ├── OnlyFans Session Manager-1.0.0-mac.dmg  ← Этот файл!
      └── mac/
          └── OnlyFans Session Manager.app
```

---

## 🎯 Типы сборки

### Обычная сборка (текущая архитектура)
```bash
npm run build:mac
```
- Создает .dmg для вашего процессора (Intel или Apple Silicon)
- **Быстрее**
- Подходит для личного использования

### Универсальная сборка (Intel + Apple Silicon)
```bash
npm run build:mac:universal
```
- Создает Universal Binary (.dmg работает на Intel и Apple Silicon)
- **Медленнее** (собирает для обеих архитектур)
- Подходит для распространения другим пользователям
- **Рекомендуется** для публичной раздачи

---

## 📦 Что делать с .dmg файлом?

### Установка на свой Mac
1. Найдите файл `OnlyFans Session Manager-1.0.0-mac.dmg` в папке `dist/`
2. Дважды кликните по .dmg файлу
3. Перетащите иконку приложения в папку Applications
4. Готово! Запускайте из Launchpad или Applications

### Распространение другим пользователям
1. Загрузите .dmg на облако (Google Drive, Dropbox, etc.)
2. Поделитесь ссылкой
3. Пользователи скачивают .dmg и устанавливают как обычное Mac приложение

---

## 🔧 Настройка приложения

### Изменить имя приложения
В `package.json`:
```json
"build": {
  "productName": "Ваше Название"
}
```

### Изменить версию
В `package.json`:
```json
"version": "1.0.1"
```

### Добавить иконку
1. Создайте файл `icon.icns` (1024x1024 PNG → конвертируйте в .icns)
2. Положите в папку `desktop/`
3. Обновите `package.json`:
```json
"mac": {
  "icon": "icon.icns"
}
```

**Онлайн конвертеры:**
- https://cloudconvert.com/png-to-icns
- https://anyconv.com/png-to-icns-converter/

---

## ⚠️ Распространенные проблемы

### Ошибка: "Cannot build for macOS on Windows/Linux"
**Решение:** Сборку .dmg можно делать **только на macOS**

### Ошибка: "xcode-select: error: tool 'xcodebuild' requires Xcode"
**Решение:** Установите Xcode Command Line Tools:
```bash
xcode-select --install
```

### Ошибка: "Application is damaged and can't be opened"
**Решение:** macOS блокирует неподписанные приложения. Разрешите запуск:
```bash
# Замените путь на актуальный
xattr -cr "/Applications/OnlyFans Session Manager.app"
```

Или через Системные настройки:
1. System Settings → Privacy & Security
2. Найдите сообщение о заблокированном приложении
3. Нажмите "Open Anyway"

### Сборка занимает очень много времени
**Причина:** Универсальная сборка собирает для двух архитектур
**Решение:** Используйте обычную сборку для тестирования:
```bash
npm run build:mac
```

---

## 🔐 Подписывание приложения (опционально)

Для публичного распространения рекомендуется подписать приложение через Apple Developer Account.

### Требования:
- Apple Developer Account ($99/год)
- Developer ID Application certificate

### Настройка:
```json
"mac": {
  "identity": "Developer ID Application: Your Name (TEAM_ID)",
  "hardenedRuntime": true,
  "gatekeeperAssess": false
}
```

Установите переменные окружения:
```bash
export CSC_LINK=/path/to/certificate.p12
export CSC_KEY_PASSWORD=your_password
npm run build:mac
```

**Без подписи:** Приложение будет работать, но пользователям нужно будет вручную разрешать запуск.

---

## 📊 Размер файла

- **Intel-only:** ~100-150 MB
- **Apple Silicon-only:** ~100-150 MB
- **Universal (Intel + ARM):** ~200-250 MB

---

## ✅ Чеклист перед сборкой

- [ ] Установлен Node.js 18+
- [ ] Установлены Xcode Command Line Tools
- [ ] Выполнена команда `npm install` в папке `desktop/`
- [ ] Обновлена версия в `package.json`
- [ ] Приложение работает через `npm run start`
- [ ] Закрыт Electron (если запущен)

---

## 🎉 Готово!

После выполнения `npm run build:mac` вы получите готовый .dmg файл для установки на macOS.

**Путь к файлу:**
```
desktop/dist/OnlyFans Session Manager-1.0.0-mac.dmg
```

Просто откройте .dmg, перетащите иконку в Applications, и приложение готово к использованию! 🚀
