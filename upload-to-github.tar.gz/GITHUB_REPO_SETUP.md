# ✅ GitHub репозиторий готов!

Репозиторий создан: **https://github.com/id-mozart/onlyfans-session-manager**

Переменная `GITHUB_REPO=id-mozart/onlyfans-session-manager` настроена.

Интеграция GitHub подключена через Replit.

---

## 🚀 Последний шаг (2 минуты)

Чтобы включить автоматическую сборку .dmg файлов, загрузите workflow файл в репозиторий:

### Вариант 1: Копирование через GitHub (рекомендуется)

1. Откройте: **https://github.com/id-mozart/onlyfans-session-manager**

2. Нажмите: **"Add file" → "Create new file"**

3. В поле "Name your file" введите:
   ```
   .github/workflows/build-dmg.yml
   ```
   
4. Откройте этот файл в Replit: `.github/workflows/build-dmg.yml`
   
5. **Скопируйте ВСЁ содержимое** и вставьте в окно GitHub

6. Нажмите **"Commit changes..."** → **"Commit changes"**

7. Готово! Workflow загружен

### Вариант 2: Через Git (если есть опыт)

```bash
# Клонируйте репозиторий
git clone https://github.com/id-mozart/onlyfans-session-manager.git
cd onlyfans-session-manager

# Создайте папку workflows
mkdir -p .github/workflows

# Скопируйте файл из проекта Replit
# (содержимое из .github/workflows/build-dmg.yml)

# Закоммитьте и запушьте
git add .github/workflows/build-dmg.yml
git commit -m "Add DMG build workflow"
git push
```

---

## 🎉 Готово! Теперь можно собирать .dmg

После загрузки workflow файла:

1. Откройте страницу **/build-dmg** в этом приложении
2. Нажмите **"Сгенерировать DMG"** - сборка запустится!
3. Через 5-10 минут появится кнопка **"Скачать DMG"**

Проверить статус: https://github.com/id-mozart/onlyfans-session-manager/actions

## 🔧 Что делает workflow?

- Запускается на macOS runner в GitHub Actions
- Собирает универсальный .dmg файл (Intel + Apple Silicon)
- Создаёт GitHub Release с готовым файлом
- Сохраняет артефакт на 30 дней

## 📝 Примечание

Переменная окружения `GITHUB_REPO` уже настроена:
```
GITHUB_REPO=id-mozart/onlyfans-session-manager
```

Интеграция GitHub подключена через Replit - токен управляется автоматически.

## ❓ Помощь

Если возникнут проблемы, проверьте:
- Workflow файл загружен по пути `.github/workflows/build-dmg.yml`
- GitHub Actions включены в настройках репозитория (Settings → Actions)
- Страница Actions доступна: https://github.com/id-mozart/onlyfans-session-manager/actions
